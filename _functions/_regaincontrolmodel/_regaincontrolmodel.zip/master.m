%% initialize 

%define mean of target distribution
muTlow = 0:.25:3;

%index of distribution used in previous plots
indTarget = 7;

%% generate results for all values of muT

%-------generate results from scratch--------%
% parfor i=1:numel(muTlow)
%     res = varianceSims_AH(muTlow(i));
%     allres{i} = res;
% end

%------------get discriminability------------%
% D = [];
% for i=1:numel(muTlow)
%     r = allres{i};
%     D  = [D, r.buffer.Dkl(:,1)];
% end

%-------------or load from file--------------%
p = load('discriminability.mat');
D = p.D;

%-----generate results for muTlow = 1.5------%
res = varianceSims(muTlow(indTarget));


%% plot figures used in Cosyne abstract
plotFigs(res);



%% plot dependence on target (new figs)

%generate colormap
cw = [1,1,1];
cr = [1,0,0];
cb = [0,0,1];
cRL = [];cBL = [];
for i=1:15
    cRL = [cRL;cw+(cr-cw)*i./(numel(muTlow)+3)];
    cBL = [cBL;cw+(cb-cw)*i./(numel(muTlow)+3)];
end



%plot discriminability over time
figure;hold on; 
for i=1:numel(muTlow)
    subplot(1,2,1);hold on;plot(-5:50,[D(95:100,i);D(1:50,  i)],'linewidth',2,'color',cBL(i+2,:));
    subplot(1,2,2);hold on;plot(-5:50,[D(45:50, i);D(51:100,i)],'linewidth',2,'color',cRL(i+2,:));
end
subplot(1,2,1);
xlabel('time after switch from high to low');
ylabel('discriminability');
xlim([-5,50]);ylim([.5,.9])
set(gca,'fontsize',16);

subplot(1,2,2);
xlabel('time after switch from high to low');
ylabel('discriminability');
xlim([-5,50]);ylim([.5,.9])
set(gca,'fontsize',16);
set(gcf,'color','w','Position',[200 200 1200 400])

%plot discriminability versus target mean
figure;hold on;
times = 1:5:26;
for i=1:numel(times)
    subplot(1,numel(times),i);hold on;
    plot(muTlow,D(   times(i),:),'linewidth',2,'color',cBL(end,:))
    plot(muTlow,D(50+times(i),:),'linewidth',2,'color',cRL(end,:))
    xlabel('target mean');
    ylabel('discriminability');
    set(gca,'fontsize',16);ylim([.5,.9]);xlim([0,3])
end
set(gcf,'color','w','Position',[200 200 1800 300])
